"""Governed worker execution: JARVIS dispatches, employees execute, reviewers verify."""

from __future__ import annotations

import json
import os
import re
import shlex
from pathlib import Path
from typing import Any, ClassVar

from jarvis.amaura.control_plane import AmauraControlPlane
from jarvis.amaura.evidence import (
    create_review_attestation,
    deterministic_evidence_review,
    validate_criterion_review,
)
from jarvis.amaura.gitops import (
    finalize_task_commit,
    is_git_repository,
    is_software_task,
    prepare_task_worktree,
)
from jarvis.amaura.models import GovernanceError, TaskState
from jarvis.amaura.network import fetch_public_text
from jarvis.amaura.policy import PATH_ARGUMENTS
from jarvis.tools.result import parse_tool_result
from jarvis.tools.security import tool_workspace
from jarvis.amaura.registry import get_agent
from jarvis.amaura.security import redact_sensitive_text
from jarvis.amaura.sandbox import run_governed_command, StatefulDockerSandbox
from jarvis.models import DEFAULT_MODEL, MODELS, resolve_model


class _LocalOllamaClient:
    """Device-only OpenAI-compatible client with no cloud fallback."""

    def __init__(self):
        from openai import OpenAI

        base_url = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
        self._client = OpenAI(base_url=f"{base_url}/v1", api_key="ollama", timeout=120.0)
        self.last_execution_metadata: dict[str, Any] = {}

    def chat_sync(self, *, model_id: str, messages: list[dict], tools: list[dict] | None = None):
        kwargs: dict[str, Any] = {"model": model_id, "messages": messages, "temperature": 0.2}
        if tools:
            kwargs["tools"] = tools
        try:
            response = self._client.chat.completions.create(**kwargs)
            self.last_execution_metadata = {
                "requested_provider": "local",
                "actual_provider": "ollama",
                "requested_model": model_id,
                "actual_model": str(getattr(response, "model", "") or model_id),
                "fallback_reason": "",
                "credential_id": "local",
            }
            return response
        except Exception as exc:
            raise GovernanceError("Device-only inference failed; no cloud fallback was attempted. Start Ollama and configure AMAURA_LOCAL_MODEL.") from exc


class GovernedTaskRunner:
    """Runs one company employee strictly inside a JARVIS-issued task packet."""

    _WORKSPACE_DEFAULT_ARGUMENTS: ClassVar[dict[str, str]] = {
        "search_code": "directory",
        "find_files": "directory",
        "get_project_structure": "path",
        "run_command": "cwd",
        "run_tests": "cwd",
        "lint_code": "cwd",
        "analyze_code": "cwd",
        "git_status": "cwd",
        "git_diff": "cwd",
        "git_log": "cwd",
        "index_codebase_ast": "root_dir",
        "search_symbol": "root_dir",
    }

    def __init__(self, control_plane: AmauraControlPlane, client_factory=None):
        self.control = control_plane
        self.client_factory = client_factory

    def _client(self, route: dict[str, Any], employee):
        if self.client_factory is not None:
            return self.client_factory(route, employee)
        if route["provider"] == "local":
            return _LocalOllamaClient()
        if os.environ.get("AMAURA_DISABLE_CLOUD") == "1":
            raise GovernanceError(
                "Cloud model access is disabled for this execution"
            )
        from jarvis.api import NvidiaClient

        agent_key = os.getenv(f"NVIDIA_API_KEY_{employee.agent_id.upper()}")
        allow_fallbacks = os.environ.get("AMAURA_MODEL_MODE", "local").strip().lower() == "balanced"
        return NvidiaClient(api_key=agent_key, allow_fallbacks=allow_fallbacks)

    @classmethod
    def _scope_tool_args(cls, tool_name: str, args: dict[str, Any], workspace: str) -> dict[str, Any]:
        """Make policy validation and actual tool execution resolve the same paths."""
        scoped = dict(args)
        default_argument = cls._WORKSPACE_DEFAULT_ARGUMENTS.get(tool_name)
        if default_argument and not scoped.get(default_argument):
            scoped[default_argument] = workspace
        root = Path(workspace).expanduser().resolve()
        for key, raw_value in list(scoped.items()):
            if key not in PATH_ARGUMENTS or not isinstance(raw_value, str) or not raw_value:
                continue
            candidate = Path(raw_value).expanduser()
            if not candidate.is_absolute():
                candidate = root / candidate
            scoped[key] = str(candidate.resolve())
        return scoped

    def _execute_tool(
        self,
        tool_name: str,
        args: dict[str, Any],
        execute_tool,
        sandbox: StatefulDockerSandbox | None = None,
        workspace: str | None = None,
    ) -> str:
        if tool_name == "web_fetch":
            result = fetch_public_text(
                str(args["url"]),
                max_length=int(args.get("max_length", 10_000)),
            )
            if result.startswith("❌"):
                return json.dumps({"ok": False, "data": {}, "error": result, "external_id": "", "retryable": False})
            return json.dumps({"ok": True, "data": {"output": result}, "error": None, "external_id": "", "retryable": False})
        if tool_name not in {"run_command", "run_tests", "lint_code"}:
            with tool_workspace(workspace or Path.cwd()):
                return execute_tool(tool_name, args)
        if tool_name == "run_tests":
            framework = str(args.get("framework", "") or "pytest")
            path = str(args.get("path", "."))
            test_filter = str(args.get("filter", ""))
            verbose = bool(args.get("verbose", True))
            commands: dict[str, list[str]] = {
                "pytest": ["python", "-m", "pytest", path],
                "unittest": ["python", "-m", "unittest", "discover", path],
                "jest": ["npx", "jest", path],
                "vitest": ["npx", "vitest", "run", path],
                "mocha": ["npx", "mocha", path],
                "go": ["go", "test", "./..." if path == "." else path],
                "cargo": ["cargo", "test"],
                "rspec": ["bundle", "exec", "rspec", path],
                "phpunit": ["./vendor/bin/phpunit", path],
            }
            tokens = commands[framework]
            if verbose and framework in {"pytest", "unittest", "jest", "go"}:
                tokens.append("-v" if framework != "jest" else "--verbose")
            if test_filter:
                if framework == "pytest":
                    tokens.extend(("-k", test_filter))
                elif framework == "go":
                    tokens.extend(("-run", test_filter))
                elif framework == "cargo":
                    tokens.append(test_filter)
            command = shlex.join(tokens)
        elif tool_name == "lint_code":
            linter = str(args.get("linter", "") or "ruff")
            path = str(args.get("path", "."))
            fix = bool(args.get("fix", False))
            commands = {
                "ruff": ["python", "-m", "ruff", "check", path],
                "flake8": ["python", "-m", "flake8", path],
                "eslint": ["npx", "eslint", path],
                "golangci-lint": ["golangci-lint", "run", path],
                "clippy": ["cargo", "clippy"],
            }
            tokens = commands[linter]
            if fix and linter in {"ruff", "eslint"}:
                tokens.append("--fix")
            command = shlex.join(tokens)
        else:
            command = str(args["command"])
        timeout = max(1, min(int(args.get("timeout", 120)), 300))
        try:
            if sandbox:
                completed = sandbox.run(command, timeout=timeout)
            else:
                completed = run_governed_command(
                    command,
                    workspace=str(args["cwd"]),
                    timeout=timeout,
                )
        except GovernanceError as exc:
            return json.dumps({"ok": False, "data": {}, "error": f"Cannot execute command: {exc}", "external_id": "", "retryable": False})
        output = completed.stdout
        if completed.stderr:
            output += ("\n" if output else "") + completed.stderr
        output = output.strip() or "(no output)"
        if completed.returncode != 0:
            return json.dumps({"ok": False, "data": {}, "error": f"Command failed (exit code {completed.returncode}):\n{output}", "external_id": "", "retryable": False})
        return json.dumps({"ok": True, "data": {"output": output}, "error": None, "external_id": "", "retryable": False})

    def run(self, task_id: str, max_iterations: int = 12) -> dict[str, Any]:
        # repository_write tasks use the same isolated Git path as engineering delivery.
        max_iterations = max(1, min(max_iterations, 30))
        task = self.control.store.get_work_item(task_id)
        if task["state"] in {TaskState.ASSIGNED.value, TaskState.BLOCKED.value}:
            task = self.control.start_task(task_id, actor="jarvis")
        if task["state"] == TaskState.BLOCKED.value:
            return {"status": "blocked", "task": task, "reason": "Dependencies are incomplete"}
        if task["state"] != TaskState.IN_PROGRESS.value:
            raise GovernanceError(f"Task runner cannot execute state '{task['state']}'")

        packet_dict = self.control.task_packet(task_id, actor="jarvis")
        if (
            is_software_task(task)
            and packet_dict.get("_workspace")
            and is_git_repository(packet_dict["_workspace"])
        ):
            worktree = prepare_task_worktree(packet_dict["_workspace"], task_id)
            metadata = {
                **dict(task.get("metadata") or {}),
                "git_repository_root": worktree.repository_root,
                "git_worktree_path": worktree.worktree_path,
                "git_branch": worktree.branch,
                "git_base_branch": worktree.base_branch,
                "git_base_commit": worktree.base_commit,
            }
            task = self.control.store.update_work_item(task_id, metadata=metadata)
            packet_dict["_workspace"] = worktree.worktree_path
            packet_dict["repository_context"]["workspace_dir"] = worktree.worktree_path
        elif is_software_task(task) and os.environ.get("AMAURA_STRICT_GIT", "0") == "1":
            raise GovernanceError("Repository-writing tasks require a clean Git repository in strict launch mode")

        route = packet_dict.pop("_model_route")
        workspace = packet_dict.pop("_workspace")
        approved_names = set(packet_dict.pop("_approved_tools"))

        from jarvis.amaura.models import CanonicalTaskPacket
        packet_model = CanonicalTaskPacket.model_validate(packet_dict)
        clean_packet = packet_model.model_dump(mode="json")

        from jarvis.tools.registry import ALL_TOOL_DEFINITIONS, execute_tool

        employee = get_agent(task["owner_id"])
        local_only = route["provider"] == "local"
        if local_only:
            model_cfg = {"id": route["model_key"], "supports_tools": True}
        else:
            resolved_model = resolve_model(route["model_key"])
            model_cfg = {
                "id": (resolved_model or {}).get("id", route["model_key"]),
                "supports_tools": (resolved_model or {}).get("supports_tools", True),
            }
        tools = [definition for definition in ALL_TOOL_DEFINITIONS if definition["function"]["name"] in approved_names]
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": employee.system_prompt + "\n\nReturn a concise completion summary. Do not claim success unless tool results support it."},
            {"role": "user", "content": "JARVIS TASK PACKET:\n" + json.dumps(clean_packet, indent=2)},
        ]
        client = self._client(route, employee)
        evidence: list[dict[str, Any]] = []
        final_response = ""
        iterations = 0
        response = None  # holds the latest response for the final execution receipt
        total_input_tokens = 0
        total_output_tokens = 0
        actual_models: list[str] = []
        provider_executions: list[dict[str, Any]] = []

        sandbox = None
        sandbox_mode = os.environ.get("AMAURA_SANDBOX_MODE", "docker").strip().lower()
        if sandbox_mode == "docker":
            try:
                sandbox = StatefulDockerSandbox(workspace=workspace)
            except GovernanceError as exc:
                sandbox_error = str(exc)
                record = self.control.evidence.put_text(sandbox_error, source=f"task:{task_id}:sandbox_init_failure")
                evidence.append({
                    "type": "sandbox_init_failure",
                    "reference": record.reference,
                    "sha256": record.sha256,
                    "byte_length": record.byte_length,
                    "success": False,
                    "excerpt": sandbox_error[:500],
                })
        
        try:
            for iteration in range(1, max_iterations + 1):
                iterations = iteration
                response = client.chat_sync(model_id=model_cfg["id"], messages=messages, tools=tools if model_cfg.get("supports_tools") and tools else None)
                usage = getattr(response, "usage", None)
                total_input_tokens += int(getattr(usage, "prompt_tokens", 0) or 0)
                total_output_tokens += int(getattr(usage, "completion_tokens", 0) or 0)
                metadata = dict(getattr(client, "last_execution_metadata", {}) or {})
                actual_model = str(
                    metadata.get("actual_model")
                    or getattr(response, "model", route["model_key"])
                    or route["model_key"]
                )
                if actual_model not in actual_models:
                    actual_models.append(actual_model)
                if metadata and metadata not in provider_executions:
                    provider_executions.append(metadata)
                if (
                    os.environ.get("AMAURA_MODEL_MODE", "local").strip().lower() == "cloud"
                    and route["provider"] == "nvidia"
                    and str(metadata.get("actual_provider") or "nvidia") != "nvidia"
                ):
                    raise GovernanceError("Cloud-only worker execution may not fall back to another provider")
                choice = response.choices[0]
                content = choice.message.content or ""
                tool_calls = choice.message.tool_calls or []
                if not tool_calls:
                    final_response = content.strip()
                    break

                messages.append(
                    {
                        "role": "assistant",
                        "content": content or None,
                        "tool_calls": [{"id": call.id, "type": "function", "function": {"name": call.function.name, "arguments": call.function.arguments}} for call in tool_calls],
                    }
                )
                for call in tool_calls:
                    try:
                        args = json.loads(call.function.arguments)
                    except json.JSONDecodeError as exc:
                        raise GovernanceError(f"Employee produced invalid arguments for {call.function.name}") from exc
                    if call.function.name == "run_command" and not args.get("cwd"):
                        args["cwd"] = workspace
                    scoped_args = self._scope_tool_args(call.function.name, args, workspace)
                    self.control.authorize_tool(task_id, employee.agent_id, call.function.name, scoped_args)
                    result = self._execute_tool(
                        call.function.name,
                        scoped_args,
                        execute_tool,
                        sandbox=sandbox,
                        workspace=workspace,
                    )
                    result = redact_sensitive_text(result)
                    record = self.control.evidence.put_text(
                        result,
                        source=f"task:{task_id}:tool:{call.function.name}",
                    )
                    parsed_result = parse_tool_result(result)
                    success = parsed_result.ok
                    excerpt_str = str(parsed_result.data.get("output", result))
                    if parsed_result.error:
                        excerpt_str += "\nError: " + parsed_result.error

                    evidence.append(
                        {
                            "type": "tool_result",
                            "reference": record.reference,
                            "sha256": record.sha256,
                            "byte_length": record.byte_length,
                            "tool": call.function.name,
                            "success": success,
                            "excerpt": excerpt_str[:500],
                        }
                    )
                    messages.append({"role": "tool", "tool_call_id": call.id, "content": result})
            else:
                raise GovernanceError(f"Employee exceeded the {max_iterations}-iteration execution limit")
        finally:
            if sandbox:
                sandbox.close()

        if not final_response.strip():
            raise GovernanceError("Employee returned no completion summary")

        if is_software_task(task) and task.get("metadata", {}).get("git_worktree_path"):
            metadata = dict(task.get("metadata") or {})
            from jarvis.amaura.gitops import WorktreeRecord

            worktree = WorktreeRecord(
                repository_root=str(metadata.get("git_repository_root", "")),
                worktree_path=str(metadata.get("git_worktree_path", "")),
                branch=str(metadata.get("git_branch", "")),
                base_branch=str(metadata.get("git_base_branch", "")),
                base_commit=str(metadata.get("git_base_commit", "")),
            )
            commit = finalize_task_commit(
                worktree,
                task_id=task_id,
                title=str(task.get("title", "software update")),
            )
            metadata.update(
                {
                    "git_commit": commit.commit,
                    "git_changed_files": list(commit.changed_files),
                }
            )
            task = self.control.store.update_work_item(task_id, metadata=metadata)
            commit_record = self.control.evidence.put_json(
                commit.to_dict(),
                source=f"task:{task_id}:git_commit",
            )
            evidence.append(
                {
                    "type": "git_commit",
                    "reference": commit_record.reference,
                    "sha256": commit_record.sha256,
                    "byte_length": commit_record.byte_length,
                    "success": True,
                    "excerpt": (
                        f"commit={commit.commit[:12]} files={len(commit.changed_files)} "
                        f"diff_bytes={len(commit.diff.encode('utf-8', errors='replace'))}"
                    ),
                }
            )

        if not evidence:
            if task.get("acceptance_criteria"):
                raise GovernanceError("Employee submitted no verifiable evidence to satisfy acceptance criteria. Agent prose is insufficient.")
            record = self.control.evidence.put_text(
                final_response,
                source=f"task:{task_id}:agent_output",
            )
            evidence.append(
                {
                    "type": "agent_output",
                    "reference": record.reference,
                    "sha256": record.sha256,
                    "byte_length": record.byte_length,
                    "success": True,
                    "excerpt": final_response[:500],
                }
            )

        estimated_cost = route["estimated_cost_cents"]
        # P0-8: record the actual model and provider for every inference, not just the route name.
        # The provider may have remapped the requested model to a fallback.
        final_provider = (
            str(provider_executions[-1].get("actual_provider"))
            if provider_executions
            else route["provider"]
        )
        model_execution_receipt = {
            "requested_route": route["model_key"],
            "requested_provider": route["provider"],
            "actual_model": actual_models[-1] if actual_models else route["model_key"],
            "models_used": actual_models,
            "provider": final_provider,
            "providers_used": [
                item.get("actual_provider") for item in provider_executions
                if item.get("actual_provider")
            ] or [route["provider"]],
            "provider_executions": provider_executions,
            "fallback_model_key": route.get("fallback_model_key"),
            "sandbox_mode": sandbox_mode,
            "container_id": getattr(sandbox, "container_id", None) if sandbox else None,
            "input_tokens": total_input_tokens,
            "output_tokens": total_output_tokens,
            "estimated_cost_cents": estimated_cost,
            "iterations": iterations,
        }
        receipt_record = self.control.evidence.put_json(
            model_execution_receipt,
            source=f"task:{task_id}:model_execution_receipt",
        )
        evidence.append(
            {
                "type": "model_execution_receipt",
                "reference": receipt_record.reference,
                "sha256": receipt_record.sha256,
                "byte_length": receipt_record.byte_length,
                "success": True,
                "excerpt": f"model={model_execution_receipt['actual_model']} provider={model_execution_receipt['provider']} tokens={model_execution_receipt['input_tokens']}+{model_execution_receipt['output_tokens']}",
            }
        )
        if estimated_cost:
            self.control.record_cost(task_id, employee.agent_id, estimated_cost, "model_inference", metadata=model_execution_receipt)
        submitted = self.control.submit_task(task_id, employee.agent_id, final_response, evidence)
        return {
            "status": submitted["state"],
            "task_id": task_id,
            "employee": employee.name,
            "iterations": iterations,
            "summary": final_response,
            "evidence": evidence,
            "model_execution_receipt": model_execution_receipt,
            "reviewer": submitted["reviewer_id"],
        }


def _extract_json_object(text: str) -> dict[str, Any]:
    candidate = text.strip()
    if candidate.startswith("```"):
        candidate = re.sub(r"^```(?:json)?\s*", "", candidate, count=1, flags=re.IGNORECASE)
        candidate = re.sub(r"\s*```$", "", candidate, count=1)
    start, end = candidate.find("{"), candidate.rfind("}")
    if start < 0 or end <= start:
        raise GovernanceError("Reviewer returned no JSON decision")
    try:
        value = json.loads(candidate[start : end + 1])
    except json.JSONDecodeError as exc:
        raise GovernanceError("Reviewer returned malformed JSON") from exc
    if not isinstance(value, dict):
        raise GovernanceError("Reviewer decision must be a JSON object")
    return value


class GovernedReviewRunner:
    """Run the registered independent reviewer without granting founder authority."""

    def __init__(self, control_plane: AmauraControlPlane, client_factory=None):
        self.control = control_plane
        self.client_factory = client_factory

    def _client(self, reviewer, *, provider: str, model_key: str):
        route = {"provider": provider, "model_key": model_key}
        if self.client_factory is not None:
            return self.client_factory(route, reviewer)
        if provider == "nvidia":
            if os.environ.get("AMAURA_DISABLE_CLOUD") == "1":
                raise GovernanceError("Cloud review is disabled for this execution")
            from jarvis.api import NvidiaClient

            reviewer_key = os.environ.get("NVIDIA_REVIEW_API_KEY", "").strip()
            return NvidiaClient(api_key=reviewer_key or None, allow_fallbacks=False)
        return _LocalOllamaClient()

    def _worker_models_from_evidence(self, task: dict[str, Any]) -> set[str]:
        models: set[str] = set()
        for item in task.get("evidence") or []:
            if item.get("type") != "model_execution_receipt":
                continue
            reference = str(item.get("reference") or "")
            if not reference:
                continue
            try:
                receipt = json.loads(self.control.evidence.get_text(reference))
            except (GovernanceError, json.JSONDecodeError):
                continue
            actual = str(receipt.get("actual_model") or "").strip()
            if actual:
                models.add(actual)
            for model in receipt.get("models_used") or []:
                value = str(model).strip()
                if value:
                    models.add(value)
        return models

    def run(self, task_id: str) -> dict[str, Any]:
        task = self.control.store.get_work_item(task_id)
        if task["state"] != TaskState.AWAITING_REVIEW.value:
            raise GovernanceError("Task is not awaiting independent review")
        reviewer_id = task["reviewer_id"]
        if not reviewer_id or reviewer_id == "founder":
            raise GovernanceError("Founder approval cannot be automated")
        if reviewer_id == task["owner_id"]:
            raise GovernanceError("No agent may certify its own work")
        self.control._ensure_agent_enabled(reviewer_id)
        reviewer = get_agent(reviewer_id)

        review_mode = os.environ.get("AMAURA_REVIEW_MODE", "local").strip().lower()
        if review_mode not in {"local", "cloud"}:
            raise GovernanceError("AMAURA_REVIEW_MODE must be local or cloud")
        worker_model = os.environ.get("AMAURA_LOCAL_MODEL", "nova:3b").strip()
        if review_mode == "cloud":
            model_id = os.environ.get("AMAURA_CLOUD_REVIEW_MODEL", "").strip()
            if not model_id:
                raise GovernanceError(
                    "AMAURA_CLOUD_REVIEW_MODEL is required when AMAURA_REVIEW_MODE=cloud"
                )
            if not (
                os.environ.get("NVIDIA_REVIEW_API_KEY", "").strip()
                or os.environ.get("NVIDIA_API_KEY", "").strip()
            ):
                raise GovernanceError(
                    "Cloud review requires NVIDIA_REVIEW_API_KEY or NVIDIA_API_KEY"
                )
            worker_models = self._worker_models_from_evidence(task)
            if model_id in worker_models:
                raise GovernanceError(
                    "Independent reviewer model must differ from every worker model used for the task"
                )
            if not worker_models and os.environ.get("AMAURA_STRICT_REVIEW", "0") == "1":
                raise GovernanceError(
                    "Strict cloud review requires a model execution receipt from the worker"
                )
            review_provider = "nvidia"
        else:
            model_id = (
                os.environ.get("AMAURA_LOCAL_REVIEW_MODEL", "").strip()
                or worker_model
            )
            if model_id == worker_model:
                raise GovernanceError(
                    "Independent automated review requires a model distinct from "
                    "AMAURA_LOCAL_MODEL"
                )
            review_provider = "local"
        deterministic = deterministic_evidence_review(task, self.control.evidence)
        failed_evidence = [
            item for item in task["evidence"] if item.get("success") is False
        ]
        review_packet = {
            "task_id": task["id"],
            "title": task["title"],
            "objective": task["description"],
            "acceptance_criteria": task["acceptance_criteria"],
            "submission_summary": task["summary"],
            "evidence": task["evidence"],
            "risk": task["risk"],
            "action_type": task["action_type"],
            "rules": ["Reject unsupported completion claims.", "Reject when any acceptance criterion lacks evidence.", "Never infer that a tool or test succeeded.", "Return JSON only."],
        }
        messages = [
            {
                "role": "system",
                "content": (
                    reviewer.system_prompt + "\n\nAct as an independent verifier. Return exactly one JSON object with "
                    '"approve" (boolean), "findings" (non-empty string), and '
                    '"criteria" (one object per acceptance criterion). Each criterion object must contain '
                    '"criterion_index" (1-based integer), "criterion" (exact text), "passed" (boolean), '
                    '"evidence_refs" (array containing only submitted evidence:// references), and "notes".'
                ),
            },
            {"role": "user", "content": "INDEPENDENT REVIEW PACKET:\n" + json.dumps(review_packet, indent=2)},
        ]
        review_client = self._client(
            reviewer, provider=review_provider, model_key=model_id
        )
        response = review_client.chat_sync(model_id=model_id, messages=messages, tools=None)
        route_metadata = dict(getattr(review_client, "last_execution_metadata", {}) or {})
        actual_provider = str(route_metadata.get("actual_provider") or review_provider).strip()
        actual_model = str(route_metadata.get("actual_model") or model_id).strip()
        if review_mode == "cloud":
            if actual_provider != "nvidia":
                raise GovernanceError(
                    "Cloud independent review may not fall back to another provider"
                )
            worker_models = self._worker_models_from_evidence(task)
            if actual_model in worker_models:
                raise GovernanceError(
                    "Actual reviewer model must differ from every worker model used for the task"
                )
        content = response.choices[0].message.content or ""
        decision = _extract_json_object(content)
        approve = decision.get("approve")
        findings = decision.get("findings")
        if not isinstance(approve, bool) or not isinstance(findings, str) or not findings.strip():
            raise GovernanceError("Reviewer decision is missing approve/findings")
        criterion_review = validate_criterion_review(task, decision, self.control.evidence)
        if not deterministic["approve"]:
            approve = False
            deterministic_findings = "; ".join(deterministic["findings"])
            findings = (
                "Rejected by deterministic evidence verification: "
                f"{deterministic_findings}. {findings.strip()}"
            )
        if not criterion_review["ok"]:
            approve = False
            findings = (
                "Rejected by criterion coverage verification: "
                + "; ".join(criterion_review["findings"])
                + ". "
                + findings.strip()
            )
        decision = {
            "approve": approve,
            "findings": findings.strip(),
            "criteria": criterion_review["criteria"],
        }
        attestation = create_review_attestation(
            task_id=task_id,
            reviewer_id=reviewer_id,
            reviewer_model=actual_model,
            reviewer_provider=actual_provider,
            requested_reviewer_model=model_id,
            decision=decision,
            deterministic_review=deterministic,
        )
        self.control.store.record_review_attestation(attestation)
        updated = self.control.review_task(task_id, actor=reviewer_id, approve=approve, findings=findings.strip(), attestation=attestation)
        self.control.store.audit(
            reviewer_id,
            "automated_independent_review",
            "task",
            task_id,
            "approved" if approve else "rejected",
            {
                "requested_model": model_id,
                "actual_model": actual_model,
                "actual_provider": actual_provider,
                "criteria": decision.get("criteria", []),
                "criterion_review": criterion_review,
                "failed_evidence": len(failed_evidence),
                "submission_sha256": deterministic["submission_sha256"],
                "attestation_signature": attestation["signature"],
            },
        )
        return {
            "task_id": task_id,
            "reviewer_id": reviewer_id,
            "reviewer_model": actual_model,
            "requested_reviewer_model": model_id,
            "reviewer_provider": actual_provider,
            "approve": approve,
            "findings": findings.strip(),
            "state": updated["state"],
            "criteria": decision.get("criteria", []),
            "criterion_review": criterion_review,
            "deterministic_review": deterministic,
            "attestation": attestation,
        }
